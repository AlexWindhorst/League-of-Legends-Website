<?php
if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $message=$_POST['message'];
    
    $to='windhorstalex@gmail.com'
    $subject='Form Submission'
    $message="Name: ".$name."/n"."Email: ".$email."/n". "Wrote the following: "."/n/n".$message;
    $headers="From: ".$email;
}
?>